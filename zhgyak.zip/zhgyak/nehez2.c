#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

#define BlockSize 1024

void write_to_file(const char *filename, char **lines, int line_count) {
    int fd;

    // Check if the file already exists
    if (access(filename, F_OK) == 0) {
        fprintf(stderr, "Error: File '%s' already exists.\n", filename);
        exit(1);
    }

    // Open the file for writing
    fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    if (fd < 0) {
        perror("Error opening file");
        exit(1);
    }

    // Write each line to the file
    for (int i = 0; i < line_count; i++) {
        if (write(fd, lines[i], strlen(lines[i])) < 0) {
            perror("Error writing to file");
            close(fd);
            exit(1);
        }
        if (write(fd, "\n", 1) < 0) {
            perror("Error writing newline to file");
            close(fd);
            exit(1);
        }
    }

    // Close the file
    close(fd);
}

int main() {
    FILE *input_file = fopen("input.txt", "r");
    if (!input_file) {
        perror("Error opening input file");
        return 1;
    }

    char **lines = NULL;
    size_t line_count = 0;
    char buffer[BlockSize];

    // Read lines from the input file
    while (fgets(buffer, sizeof(buffer), input_file)) {
        // Remove the newline character if present
        buffer[strcspn(buffer, "\n")] = '\0';

        // Allocate memory for the new line
        char *line = malloc(strlen(buffer) + 1);
        if (!line) {
            perror("Error allocating memory");
            fclose(input_file);
            return 1;
        }
        strcpy(line, buffer);

        // Reallocate memory for the lines array
        char **temp = realloc(lines, (line_count + 1) * sizeof(char *));
        if (!temp) {
            perror("Error reallocating memory");
            free(line);
            fclose(input_file);
            return 1;
        }
        lines = temp;

        // Add the new line to the array
        lines[line_count++] = line;
    }

    fclose(input_file);

    // Write the lines to the output file
    write_to_file("b.txt", lines, line_count);

    // Free allocated memory
    for (size_t i = 0; i < line_count; i++) {
        free(lines[i]);
    }
    free(lines);

    return 0;
}