#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Hiba: adj meg egy szamot parancssori argumentumkent!\n");
        return 1;
    }

    int max = atof(argv[1]);
    if (max <= 0.0) {
        fprintf(stderr, "Hiba: a megadott szam legyen pozitiv egesz!\n");
        return 1;
    }

    srand(time(NULL));
    float rnd = rand() % max;
    float rnd2=(float)rand()/RAND_MAX*(max-0.0)+0.0;
    printf("Veletlen szam: %.2f\n", rnd);
    printf("Veletlen szam 2: %.2f\n", rnd2);

    return 0;
}
