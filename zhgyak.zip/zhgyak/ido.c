#include <stdio.h>
#include <time.h>

int main() {
    // Jelenlegi idő lekérése
    time_t current_time = time(NULL);

    if (current_time == ((time_t) -1)) {
        fprintf(stderr, "Hiba: Nem sikerült lekérni az időt.\n");
        return 1;
    }

    // 6 perc (360 másodperc) hozzáadása
    current_time += 15 * 60;

    // Átalakítás helyi idővé
    struct tm *local_time = localtime(&current_time);
    if (local_time == NULL) {
        fprintf(stderr, "Hiba: Nem sikerült átalakítani helyi idővé.\n");
        return 1;
    }

    // Formázott idő kiírása stderr-re
    fprintf(stderr, "Helyi idő + 6 perc: %02d:%02d:%02d\n",
            local_time->tm_hour,
            local_time->tm_min,
            local_time->tm_sec);

    return 0;
}
