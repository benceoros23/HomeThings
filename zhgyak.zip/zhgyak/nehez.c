#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>     // read, write, close
#include <fcntl.h>      // open, O_*
#include <sys/stat.h>   // stat()

#define MAX_LINE 1024
#define OUTFILE "b.txt"

// Eljárás: kiírja a sorokat alacsony szinten egy fájlba (ha még nem létezik)
void write_to_file(char **lines, int count) {
    // Fájl megnyitása írásra, csak ha még nem létezik
    int fd = open(OUTFILE, O_WRONLY | O_CREAT | O_EXCL, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    if (fd == -1) {
        write(2, "Hiba: A b.txt fájl már létezik vagy nem hozható létre!\n", 55);
        return;
    }

    // Írás soronként
    for (int i = 0; i < count; ++i) {
        write(fd, lines[i], strlen(lines[i]));
        write(fd, "\n", 1);
    }

    close(fd);
}

int main() {
    FILE *fp = fopen("input.txt", "r");
    if (!fp) {
        perror("Nem sikerült megnyitni az input.txt fájlt");
        return 1;
    }

    char buffer[MAX_LINE];
    char **lines = NULL;
    int count = 0;

    // Soronként olvasunk, tároljuk dinamikusan
    while (fgets(buffer, sizeof(buffer), fp)) {
        buffer[strcspn(buffer, "\n")] = '\0'; // '\n' levágása

        char *line = malloc(strlen(buffer) + 1);
        if (!line) {
            fprintf(stderr, "Memóriafoglalási hiba!\n");
            fclose(fp);
            return 1;
        }
        strcpy(line, buffer);

        char **tmp = realloc(lines, (count + 1) * sizeof(char *));
        if (!tmp) {
            fprintf(stderr, "Memória újrafoglalási hiba!\n");
            fclose(fp);
            return 1;
        }

        lines = tmp;
        lines[count++] = line;
    }

    fclose(fp);

    // Írás alacsony szintű fájlkezeléssel
    write_to_file(lines, count);

    // Memória felszabadítása
    for (int i = 0; i < count; ++i)
        free(lines[i]);
    free(lines);

    return 0;
}
