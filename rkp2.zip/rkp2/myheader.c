#include <stdio.h>
#include "myheader.h"

void greet(const char* name)
{
    printf("Hello %s!\n", name);
}