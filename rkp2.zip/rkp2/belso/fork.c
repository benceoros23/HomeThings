#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

int main()
{

     //Folyamatok és a fork rendszerhívás

        //pid megszerzése, szülő pid megszerzése
        
        pid_t own_pid = getpid();
        pid_t parent_pid = getppid(); //get parent pid

        printf("A saját PID-ünk: %d\n", own_pid);
        printf("A szülő folyamat PID-je: %d\n", parent_pid);
        printf("\n");

        //fork létrehozása, futtatása
        int x_2 = 0;
        pid_t pid; //a pid_t egy egész típus

        printf("Start... x = %d\n", x_2);
        pid = fork();

        if (pid == 0)   //Child folyamat, stderr-re printel
        {
            x_2 = 1;
            fprintf(stderr, "Child... x = %d (PID is %d, Parent PID is %d)\n", x_2, getpid(), getppid());
            sleep(2); //mintha dolgozna
            fprintf(stderr, "Child ps:\n");
            system("ps -l | grep fork >&2"); //a grep-be átpipeoljuk a ps -l kimenetét
                                             //és csak azokat a sorokat kérjük, amikben
                                             //szerepel a "fork" szó.
                                             //a ">&2" kód irányítja át stderr-re
            sleep(2);
            fprintf(stderr, "End child. PID=%d\n",getpid());
            printf("\n");
        }
        else //Szülő folyamat (stdout-ra printel)
        {
            x_2 = 2;
            fprintf(stdout, "Parent... x = %d, PID is: %d\n", x_2, getpid());
            sleep(6);
            fprintf(stdout, "Parent ps:\n");
            system("ps -l | grep fork");
            sleep(2);
            fprintf(stdout, "End parent. PID=%d\n", getpid());
            printf("\n");
        }   
        
}