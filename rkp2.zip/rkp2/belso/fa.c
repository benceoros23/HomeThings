#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <unistd.h>


int main()
{
    //példa bináris fa létrehozására

        typedef struct elem
        {
            int adat;
            struct elem *bal, *jobb;

        } FaElem;

        //Ezzel létreozzuk a fa gyökerét, illetve két mutatót,
        //melyek a következő elemek memóriacímére mutatnak,
        //bal és jobb oldalt is egyaránt.

        FaElem *gyoker = (FaElem*)calloc(1,sizeof(FaElem));
        gyoker->adat = 24;
        gyoker->bal = (FaElem*)calloc(1,sizeof(FaElem));
        gyoker->jobb = (FaElem*)calloc(1,sizeof(FaElem));
        printf("Gyoker: %d\n", gyoker->adat);
        gyoker->bal->adat = 12;
        printf("Bal: %d\n", gyoker->bal->adat);
        gyoker->jobb->adat = 36;
        printf("Jobb: %d\n", gyoker->jobb->adat);
        free(gyoker);
        return 0;
}