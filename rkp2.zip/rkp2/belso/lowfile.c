#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>



int main()
{
    //low-level fájlkezelés

        char buf[1024];
        int in,out;
        int nread;

        char* fname_in = "testin.txt";
        char* fname_out = "testout.txt";
        
        in = open(fname_in, O_RDONLY);
        out = open(fname_out,O_WRONLY|O_CREAT|O_TRUNC,S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);

        //a read olvas max. BLOCKSIZEnyi helyet az in-ből
        //az adat a 'buf'-ban tárolódik
        //a beolvasott mennyiség (méret) pedig az nread-ben
        //addig fut amíg az nread-nek átadott méret > 0
        //tehát valamennyi adatot sikeresen be tud olvasni
        //a write pedig nread-nyi byteot ír a 'buf'-ból az outba
        //tehát - nread az hogy mennyi (return value of read)
        //a buf-ba megy maga az adat
        //és a write az out-ba belerakja a buf adatait
        while((nread = read(in,buf,1024)) > 0)
        {
            write(out,buf,nread);
        }
        
        close(in);
        close(out);

        printf("A testout.txt file sikeresen létre lett hozva.\n");
}