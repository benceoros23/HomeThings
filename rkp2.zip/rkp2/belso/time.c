#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

int main()
{
    //időkezelés és sleep
    printf("Sleeping for 3 seconds...\n");
    sleep(3);
    time_t *current = malloc(sizeof(time_t));
    time(current);
    char *current_time = ctime(current);
    printf("The current time is: %s", current_time);
    free(current);

    //komplexebb megoldas structtal
    time_t now = time(NULL);
    struct tm *time_now = localtime(&now);

    printf("The current year is: %d\n", time_now->tm_year+1900);
    printf("The current day of the month is: %d\n", time_now->tm_mday);
    printf("The current day is: %d\n", time_now->tm_wday);
    if (time_now->tm_wday == 0)
    {
        printf("Today is Sunday.\n");
    }
    else if (time_now->tm_wday == 1)
    {
        printf("Today is Monday.\n");
    }
    else if (time_now->tm_wday == 2)
    {
        printf("Today is Tuesday.\n");
    }
    else if (time_now->tm_wday == 3)
    {
        printf("Today is Wednesday.\n");
    }
    else if (time_now->tm_wday == 4)
    {
        printf("Today is Thursday.\n");
    }
    else if (time_now->tm_wday == 5)
    {
        printf("Today is Friday.\n");
    }
    else
    {
        printf("Today is Saturday.\n");
    }
    
    printf("The current hour is: %d\n", time_now->tm_hour);
    printf("The current minute is: %d\n", time_now->tm_min);
    printf("The current second is: %d\n", time_now->tm_sec); 
    printf("The current month is: %d\n", time_now->tm_mon + 1);
    return 0;
}