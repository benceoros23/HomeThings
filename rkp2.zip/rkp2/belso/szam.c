#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    printf("\n");
        int l, m, n, o;
        l = 14;
        m = 016;
        n = 0x5E;
        o = 0b1110;

        printf("Az l értéke decimálisan: %d\n",l);
        printf("Az m oktális szám értéke decimálisan: %d\n",m);
        printf("Az n hexadecimalis szám értéke decimálisan: %d\n",n);
        printf("Az o bináris szám értéke decimálisan: %d\n",o);
}