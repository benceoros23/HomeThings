#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Bitmaszkok és bitműveletek
        // Mi a jobbrol 4. pozicioban levo bit erteke az x valtozoban? 

        int x = 4325265;

        int maszk = 0x00000008; //binarisban 00001000

        if (x & maszk == 0)
        {
            printf("Az x jobbról 4. bitje 0.\n");
        }
        else
        {
            printf("Az x jobbról 4. bitje 1.\n");   //Az ES eredmenyeben nem minden bit 0.
        }

        
        printf("\n");

        int num = 96 >> 2;
        //shifting előtt: 96 -> 00001100000
        //shitfing után : 24 -> 00000011000
        printf("A 'num' változó eredménye 24 kell legyen.\n");
        printf("A 'num' változó értéke: %d\n", num);
}