#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#define BLOCKSIZE 1024

#if defined (__linux__)
    #define OS 1
#else
    #define OS 0
#endif

int main()
    
{
    //környezeti változó bekérése és kiiratása
    const char* env_val = "HOME";
    char *path = getenv(env_val);
    printf("%s\n", path);
    
    //operációs rendszer definiálása - lásd defineoknál
    if (OS == 1)
    {
        printf("This is running on a Linux-based system.\n");
    } 
    else
    {
        printf("This is not running on a Linux-based system.\n");
    }
    
    return 0;
    
}

