#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

int main()
{
    //pseudorandom számok

    srand(time(NULL));

        //egész szám generálása [A;B] zárt intervallumon
        //A = 5, B = 15
        int A = 5;
        int B = 15;
        int rand_int = rand()%(B-A+1) + A;
        printf("Random integer: %d\n", rand_int);

        //valós szám generálása [C;D] zárt intervallumon
        //C = 5, D = 15
        int C = 5;
        int D = 15;
        double rand_double = (D-C) * (double) rand() / RAND_MAX + C;
        printf("Random double: %lf\n", rand_double); 
        
    return 0;
}