#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <pwd.h>
#include <signal.h>


int main()
{
    //Az inode-ok kezelése

        int tmp;
        struct stat inode;
        struct passwd *pwd;
        char *example_dir = "/home/bence/Dokumentumok/rkp2/belso";

        //Bekérjük stat() függvénnyel a tmp-be, hogy létezik-e
        //a megadott directory/file
        //HA VARGA IMI ILYET ADNA ZH-N, ELLENŐRIZZÉTEK IF-EL,
        //HOGY LÉTEZIK-E!

        if(tmp<0)
        {
            fprintf(stderr, "Bad name!\n");
            return 2;
        }

        tmp = stat(example_dir, &inode);

        //Egyszerű ellenőrzés, hogy directory vagy file
        if (inode.st_mode&__S_IFDIR)
        {
            printf("%s is a directory.\n", example_dir);
        }
        if (inode.st_mode&__S_IFREG)
        {
            printf("%s is a file.\n", example_dir);
        }

        //Ennek a profi, szofisztikált megoldása
        //fent van Varga Imi oldalán, "'Inode' kezelés" név alatt.

        //inode number kiíratása:

        printf("Inode number: %d\n", (int)inode.st_ino);

        //jogok kiíratása, ehhez a ternáris operator
        //jól fog jönni:
        printf("Rights: ");

        //Az IRUSR = If (I) Read Permission (R) User (USR)
        //Az IWUSR ugyanez Write-al, az IXUSR pedig execute 
        //permissiont néz
        //Ezeknek a verziói, amik GRP-vel, illetve OTH-al
        //végződnek, a group-ra (GRP), illetve group-on
        //kívüli (other) user-ekre (OTH) vonatkoznak
        printf("%c",(inode.st_mode&S_IRUSR)? 'r' : '-');
        printf("%c",(inode.st_mode&S_IWUSR)? 'w' : '-');
        printf("%c",(inode.st_mode&S_IXUSR)? 'x' : '-');
        printf("%c",(inode.st_mode&S_IRGRP)? 'r' : '-');
        printf("%c",(inode.st_mode&S_IWGRP)? 'w' : '-');
        printf("%c",(inode.st_mode&S_IXGRP)? 'x' : '-');
        printf("%c",(inode.st_mode&S_IROTH)? 'r' : '-');
        printf("%c",(inode.st_mode&S_IWOTH)? 'w' : '-');
        printf("%c",(inode.st_mode&S_IXOTH)? 'x' : '-');
        printf("\n");

        pwd = getpwuid(inode.st_uid);
        
        //Ha a pwd talál user-t (jó return value-t kap), kiírja a usert.
        if (pwd)
        {
            printf("Owner's username: %s\n", (*pwd).pw_name);
        }

        printf("\n");
}