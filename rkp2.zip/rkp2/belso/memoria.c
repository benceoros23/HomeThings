#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <malloc.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

int main()
{
    //Memóriakezelés
        printf("Memóriakezelés\n");

        //Ez inicializálatlan memóriaterület lesz,
        //nekünk kell feltölteni.

        //int *p = (int*)malloc(100*sizeof(int));

        //Ha inicializáltat akarunk, ahhoz a calloc
        //függvényre lesz szükségünk.

        int *p_2 = (int*)calloc(100,sizeof(int));

        //ez nullákkal lesz feltöltve.

        for (int i = 0; i < 100; i++)
        {
            printf("%d, ", p_2[i]);
            if (i == 99)
            {
                printf("%d\n", p_2[i]);
            }
        }
        
        //a memset() függvény segítségével tölthető fel
        //nulla értékkel egy terület, ha csak malloc()-al
        //foglaltunk neki memóriát.
        memset(p_2, 5, 100*sizeof(int));
        for (int i = 0; i < 100; i++)
        {
            printf("%d, ", p_2[i]);
            if (i == 99)
            {
                printf("%d\n", p_2[i]);
            }
        }
        free(p_2);
   return 0;
}