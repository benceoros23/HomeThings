#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

int main()
{
    //mutatók
        //a * operatorral hozhato letre pointer
        //egy mar letezo var cimet az & operatorral kapjuk vissza
        int pointed_number = 15;
        int *p = &pointed_number;

        //%p-vel kiirathato a RAM cím is
        printf("A pointed szám memóriacíme: %p\n", p);

        //így kapható vissza a pointed_num értéke egy másik varban
        int derefer = *p;

        printf("A pointed szám értéke: %d\n", derefer);
        printf("\n");
        //Tömbök esetén lehet mutatni pontos elemekre is.
        //Ez aritmetikai műveletekkel érhető el.

        char *teststring = "Ez egy teszt szoveg.";

        char *c = teststring;

        printf("Így lehet bejárni karakterenként egy szöveget.\n");
        while (*c != '\0')
        {
            printf("Character: %c | Address: %p\n", *c, c);
            c++;
        }

        c = teststring;

        printf("\n");

        printf("Specifikus karakterek elérése:\n");
        printf("Első karakter: %c\n", *(c+0));
        printf("Ötödik karakter: %c\n", *(c+4));
        printf("Kilencedik karakter: %c\n", *(c+8));
        printf("\n");

        //A tömbök esetén megegyezik a [] egyfajta
        //címoperátorral. Ergo ha azt írom hogy A = Tomb[2],
        //az egyenlő lesz azzal, mintha azt mondanám, hogy
        //B = *(Tomb+2)
        printf("Elemek keresése tömbben:\n");
        int tomb[10] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
        int elso, masodik;
        elso = tomb[2];
        masodik = *(tomb+2);
        printf("Sima tömb notation-el: %d\n", elso);
        printf("Pointer notation-el: %d\n", masodik);

        //Itt látható hogy az "elso" es "masodik"
        //valtozo azonos lesz.

    return 0;
}