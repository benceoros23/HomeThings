#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "myheader.h"
#include <malloc.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#define BLOCKSIZE 1024

#if defined (__linux__)
    #define OS 1
#else
    #define OS 0
#endif

int main()
{
    //környezeti változó bekérése és kiiratása
    const char* env_val = "HOME";
    char *path = getenv(env_val);
    
    printf("%s\n", path);

    //commandok futtatása C-n belül
    system("ls *.c > code.txt");


    //operációs rendszer definiálása - lásd defineoknál
    if (OS == 1)
    {
        printf("This is running on a Linux-based system.\n");
    }

    //időkezelés és sleep
    printf("Sleeping for 3 seconds...\n");
    sleep(3);
    time_t *current = malloc(sizeof(time_t));
    time(current);
    char *current_time = ctime(current);
    printf("The current time is: %s", current_time);
    free(current);

    //komplexebb megoldas structtal
    time_t now = time(NULL);
    struct tm *time_now = localtime(&now);

    printf("The current year is: %d\n", time_now->tm_year + 1900);
    printf("The current day of the month is: %d\n", time_now->tm_mday);
    
    //pseudorandom számok

    srand(time(NULL));

        //egész szám generálása [A;B] zárt intervallumon
        //A = 5, B = 15
        int A = 5;
        int B = 15;
        int rand_int = rand()%(B-A+1) + A;
        printf("Random integer: %d\n", rand_int);

        //valós szám generálása [C;D] zárt intervallumon
        //C = 5, D = 15
        int C = 5;
        int D = 15;
        double rand_double = (D-C) * (double) rand() / RAND_MAX + C;
        printf("Random double: %lf\n", rand_double); 
    
        //saját header file (lásd "myheader.h" és "myheader.c" a mappában)
        greet("Ákos");
        printf("The value of pi is approx. %.2f\n.",PI);

        //mutatók

        //a * operatorral hozhato letre pointer
        //egy mar letezo var cimet az & operatorral kapjuk vissza
        int pointed_number = 15;
        int *p = &pointed_number;

        //%p-vel kiirathato a RAM cím is
        printf("A pointed szám memóriacíme: %p\n", p);

        //így kapható vissza a pointed_num értéke egy másik varban
        int derefer = *p;

        printf("A pointed szám értéke: %d\n", derefer);
        printf("\n");
        //Tömbök esetén lehet mutatni pontos elemekre is.
        //Ez aritmetikai műveletekkel érhető el.

        char *teststring = "Ez egy teszt szoveg.";

        char *c = teststring;

        printf("Így lehet bejárni karakterenként egy szöveget.\n");
        while (*c != '\0')
        {
            printf("Character: %c | Address: %p\n", *c, c);
            c++;
        }

        c = teststring;

        printf("\n");

        printf("Specifikus karakterek elérése:\n");
        printf("Első karakter: %c\n", *(c+0));
        printf("Ötödik karakter: %c\n", *(c+4));
        printf("Kilencedik karakter: %c\n", *(c+8));
        printf("\n");

        //A tömbök esetén megegyezik a [] egyfajta
        //címoperátorral. Ergo ha azt írom hogy A = Tomb[2],
        //az egyenlő lesz azzal, mintha azt mondanám, hogy
        //B = *(Tomb+2)
        printf("Elemek keresése tömbben:\n");
        int tomb[10] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
        int elso, masodik;
        elso = tomb[2];
        masodik = *(tomb+2);
        printf("Sima tömb notation-el: %d\n", elso);
        printf("Pointer notation-el: %d\n", masodik);

        //Itt látható hogy az "elso" es "masodik"
        //valtozo azonos lesz.

        //Memóriakezelés
        printf("Memóriakezelés\n");

        //Ez inicializálatlan memóriaterület lesz,
        //nekünk kell feltölteni.

        //int *p = (int*)malloc(100*sizeof(int));

        //Ha inicializáltat akarunk, ahhoz a calloc
        //függvényre lesz szükségünk.

        int *p_2 = (int*)calloc(100,sizeof(int));

        //ez nullákkal lesz feltöltve.

        for (int i = 0; i < 100; i++)
        {
            printf("%d, ", p_2[i]);
            if (i == 99)
            {
                printf("%d\n", p_2[i]);
            }
        }

        //a memset() függvény segítségével tölthető fel
        //nulla értékkel egy terület, ha csak malloc()-al
        //foglaltunk neki memóriát.

        //példa bináris fa létrehozására

        typedef struct elem
        {
            int adat;
            struct elem *bal, *jobb;

        } FaElem;

        //Ezzel létreozzuk a fa gyökerét, illetve két mutatót,
        //melyek a következő elemek memóriacímére mutatnak,
        //bal és jobb oldalt is egyaránt.

        FaElem *gyoker = (FaElem*)calloc(1,sizeof(FaElem));
        gyoker->adat = 24;
        gyoker->bal = (FaElem*)calloc(1,sizeof(FaElem));
        gyoker->jobb = (FaElem*)calloc(1,sizeof(FaElem));

        free(gyoker);

        //Hogyan lehet int-eket megadni C-ben?
        printf("\n");
        int l, m, n, o;
        l = 14;
        m = 016;
        n = 0x5E;
        o = 0b1110;

        printf("Az l értéke decimálisan: %d\n",l);
        printf("Az m oktális szám értéke decimálisan: %d\n",m);
        printf("Az n hexadecimalis szám értéke decimálisan: %d\n",n);
        printf("Az o bináris szám értéke decimálisan: %d\n",o);

        //Bitmaszkok és bitműveletek
        // Mi a jobbrol 4. pozicioban levo bit erteke az x valtozoban? 

        int x = 4325265;

        int maszk = 0x00000008; //binarisban 00001000

        if (x & maszk == 0)
        {
            printf("Az x jobbról 4. bitje 0.\n");
        }
        else
        {
            printf("Az x jobbról 4. bitje 1.\n");   //Az ES eredmenyeben nem minden bit 0.
        }

        free(p_2);
        printf("\n");

        int num = 96 >> 2;
        //shifting előtt: 96 -> 00001100000
        //shitfing után : 24 -> 00000011000
        printf("A 'num' változó eredménye 24 kell legyen.\n");
        printf("A 'num' változó értéke: %d\n", num);
        
        //low-level fájlkezelés

        char buf[BLOCKSIZE];
        int in,out;
        int nread;

        char* fname_in = "testin.txt";
        char* fname_out = "testout.txt";
        
        in = open(fname_in, O_RDONLY);
        out = open(fname_out,O_WRONLY|O_CREAT|O_TRUNC,S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);

        while((nread = read(in,buf,BLOCKSIZE)) > 0)
        {
            write(out,buf,nread);
        }
        
        close(in);
        close(out);

        printf("A testout.txt file sikeresen létre lett hozva.\n");

    return 0;
}