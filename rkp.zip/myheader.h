#ifndef MYHEADER_H
#define MYHEADER_H

void greet(const char* name);

#define PI 3.14159

#endif