#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "myheader.h"
#include <malloc.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <pwd.h>
#include <signal.h>

#define BLOCKSIZE 1024

#if defined (__linux__)
    #define OS 1
#else
    #define OS 0
#endif

int main()
{
    //környezeti változó bekérése és kiiratása
    const char* env_val = "HOME";
    char *path = getenv(env_val);
    
    printf("%s\n", path);

    //commandok futtatása C-n belül
    system("ls *.c > code.txt");


    //operációs rendszer definiálása - lásd defineoknál
    if (OS == 1)
    {
        printf("This is running on a Linux-based system.\n");
    }

    //időkezelés és sleep
    printf("Sleeping for 3 seconds...\n");
    sleep(3);
    time_t *current = malloc(sizeof(time_t));
    time(current);
    char *current_time = ctime(current);
    printf("The current time is: %s", current_time);
    free(current);

    //komplexebb megoldas structtal
    time_t now = time(NULL);
    struct tm *time_now = localtime(&now);

    printf("The current year is: %d\n", time_now->tm_year + 1900);
    printf("The current day of the month is: %d\n", time_now->tm_mday);
    
    //pseudorandom számok

    srand(time(NULL));

        //egész szám generálása [A;B] zárt intervallumon
        //A = 5, B = 15
        int A = 5;
        int B = 15;
        int rand_int = rand()%(B-A+1) + A;
        printf("Random integer: %d\n", rand_int);

        //valós szám generálása [C;D] zárt intervallumon
        //C = 5, D = 15
        int C = 5;
        int D = 15;
        double rand_double = (D-C) * (double) rand() / RAND_MAX + C;
        printf("Random double: %lf\n", rand_double); 
    
    //saját header file (lásd "myheader.h" és "myheader.c" a mappában)
        greet("Ákos");
        printf("The value of pi is approx. %.2f\n.",PI);

    //mutatók

        //a * operatorral hozhato letre pointer
        //egy mar letezo var cimet az & operatorral kapjuk vissza
        int pointed_number = 15;
        int *p = &pointed_number;

        //%p-vel kiirathato a RAM cím is
        printf("A pointed szám memóriacíme: %p\n", p);

        //így kapható vissza a pointed_num értéke egy másik varban
        int derefer = *p;

        printf("A pointed szám értéke: %d\n", derefer);
        printf("\n");
        //Tömbök esetén lehet mutatni pontos elemekre is.
        //Ez aritmetikai műveletekkel érhető el.

        char *teststring = "Ez egy teszt szoveg.";

        char *c = teststring;

        printf("Így lehet bejárni karakterenként egy szöveget.\n");
        while (*c != '\0')
        {
            printf("Character: %c | Address: %p\n", *c, c);
            c++;
        }

        c = teststring;

        printf("\n");

        printf("Specifikus karakterek elérése:\n");
        printf("Első karakter: %c\n", *(c+0));
        printf("Ötödik karakter: %c\n", *(c+4));
        printf("Kilencedik karakter: %c\n", *(c+8));
        printf("\n");

        //A tömbök esetén megegyezik a [] egyfajta
        //címoperátorral. Ergo ha azt írom hogy A = Tomb[2],
        //az egyenlő lesz azzal, mintha azt mondanám, hogy
        //B = *(Tomb+2)
        printf("Elemek keresése tömbben:\n");
        int tomb[10] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
        int elso, masodik;
        elso = tomb[2];
        masodik = *(tomb+2);
        printf("Sima tömb notation-el: %d\n", elso);
        printf("Pointer notation-el: %d\n", masodik);

        //Itt látható hogy az "elso" es "masodik"
        //valtozo azonos lesz.

    //Memóriakezelés
        printf("Memóriakezelés\n");

        //Az alábbi inicializálatlan memóriaterület lesz,
        //nekünk kell feltölteni.

        //int *p = (int*)malloc(100*sizeof(int));

        //a memset() függvény segítségével tölthető fel
        //nulla értékkel egy terület, ha csak malloc()-al
        //foglaltunk neki memóriát.
        
        //memset(p, 0, 100*sizeof(int));

        //Ha inicializáltat akarunk, ahhoz a calloc
        //függvényre lesz szükségünk.

        int *p_2 = (int*)calloc(100,sizeof(int));

        //ez nullákkal lesz feltöltve.

        for (int i = 0; i < 100; i++)
        {
            printf("%d, ", p_2[i]);
            if (i == 99)
            {
                printf("%d\n", p_2[i]);
            }
        }

        

        //példa bináris fa létrehozására

        typedef struct elem
        {
            int adat;
            struct elem *bal, *jobb;

        } FaElem;

        //Ezzel létreozzuk a fa gyökerét, illetve két mutatót,
        //melyek a következő elemek memóriacímére mutatnak,
        //bal és jobb oldalt is egyaránt.

        FaElem *gyoker = (FaElem*)calloc(1,sizeof(FaElem));
        gyoker->adat = 24;
        gyoker->bal = (FaElem*)calloc(1,sizeof(FaElem));
        gyoker->jobb = (FaElem*)calloc(1,sizeof(FaElem));

        free(gyoker);

        //Hogyan lehet int-eket megadni C-ben?
        printf("\n");
        int l, m, n, o;
        l = 14;
        m = 016;
        n = 0x5E;
        o = 0b1110;

        printf("Az l értéke decimálisan: %d\n",l);
        printf("Az m oktális szám értéke decimálisan: %d\n",m);
        printf("Az n hexadecimalis szám értéke decimálisan: %d\n",n);
        printf("Az o bináris szám értéke decimálisan: %d\n",o);

     //Bitmaszkok és bitműveletek
        // Mi a jobbrol 4. pozicioban levo bit erteke az x valtozoban? 

        int x = 4325265;

        int maszk = 0x00000008; //binarisban 00001000

        if (x & maszk == 0)
        {
            printf("Az x jobbról 4. bitje 0.\n");
        }
        else
        {
            printf("Az x jobbról 4. bitje 1.\n");   //Az ES eredmenyeben nem minden bit 0.
        }

        free(p_2);
        printf("\n");

        int num = 96 >> 2;
        //shifting előtt: 96 -> 00001100000
        //shitfing után : 24 -> 00000011000
        printf("A 'num' változó eredménye 24 kell legyen.\n");
        printf("A 'num' változó értéke: %d\n", num);
        
    //low-level fájlkezelés

        char buf[BLOCKSIZE];
        int in,out;
        int nread;

        char* fname_in = "testin.txt";
        char* fname_out = "testout.txt";
        
        in = open(fname_in, O_RDONLY);
        out = open(fname_out,O_WRONLY|O_CREAT|O_TRUNC,S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);

        //a read olvas max. BLOCKSIZEnyi helyet az in-ből
        //az adat a 'buf'-ban tárolódik
        //a beolvasott mennyiség (méret) pedig az nread-ben
        //addig fut amíg az nread-nek átadott méret > 0
        //tehát valamennyi adatot sikeresen be tud olvasni
        //a write pedig nread-nyi byteot ír a 'buf'-ból az outba
        //tehát - nread az hogy mennyi (return value of read)
        //a buf-ba megy maga az adat
        //és a write az out-ba belerakja a buf adatait
        while((nread = read(in,buf,BLOCKSIZE)) > 0)
        {
            write(out,buf,nread);
        }
        
        close(in);
        close(out);

        printf("A testout.txt file sikeresen létre lett hozva.\n");

    //Könyvtár és inode kezelés

    //Egyszerű ls implementáció, á lá Varga Imre
        
        //Ha a saját mappádat akarok beolvastatni,
        //írd át a "currentdir" var-t a saját path-odra
        
        //path-hoz egy üres DIR*, amibe az opendir fogja beolvasni
        //a megadott elérési útvonalat.

        DIR* currentdir;
        
        //readdir visszatérési értékéhez egy üres dirent* struct
        struct dirent* entry;
        

        //megnyitjuk currentdir-be a választott mappát
        currentdir = opendir("/home/angelak0s/Desktop/rkp");
        
        //Ebbe fogja beolvasni a mappába tartozó fájlokat
        //a readdir() függvény,
        //egészen addig míg NULL-t dob vissza (nincs több fájl)

        while ((entry = readdir(currentdir)) != NULL)
        {   
            //Az "entry" dirent struct-ból kiolvassuk a neveket
            printf("%s  ", entry -> d_name);
        }  
    
        printf("\n");

        //mappaváltoztatás futásidőben - chdir() függvény
        chdir("/home/angelak0s/Downloads");

        //átadjuk a currentdir-nek egy "." operátorral
        //az új mappát
        currentdir = opendir(".");

        while ((entry = readdir(currentdir)) != NULL)
        {   
            printf("%s  ", entry -> d_name);
        }
        
        printf("\n");

        //bezárjuk a végén a mappát
        closedir(currentdir);

        printf("\n");

    //Az inode-ok kezelése

        int tmp;
        struct stat inode;
        struct passwd *pwd;
        char *example_dir = "/home/angelak0s/Desktop/rkp/jegyzet.c";

        //Bekérjük stat() függvénnyel a tmp-be, hogy létezik-e
        //a megadott directory/file
        //HA VARGA IMI ILYET ADNA ZH-N, ELLENŐRIZZÉTEK IF-EL,
        //HOGY LÉTEZIK-E!

        if(tmp<0)
        {
            fprintf(stderr, "Bad name!\n");
            return 2;
        }

        tmp = stat(example_dir, &inode);

        //Egyszerű ellenőrzés, hogy directory vagy file
        if (inode.st_mode&__S_IFDIR)
        {
            printf("%s is a directory.\n", example_dir);
        }
        if (inode.st_mode&__S_IFREG)
        {
            printf("%s is a file.\n", example_dir);
        }

        //Ennek a profi, szofisztikált megoldása
        //fent van Varga Imi oldalán, "'Inode' kezelés" név alatt.

        //inode number kiíratása:

        printf("Inode number: %d\n", (int)inode.st_ino);

        //jogok kiíratása, ehhez a ternáris operator
        //jól fog jönni:
        printf("Rights: ");

        //Az IRUSR = If (I) Read Permission (R) User (USR)
        //Az IWUSR ugyanez Write-al, az IXUSR pedig execute 
        //permissiont néz
        //Ezeknek a verziói, amik GRP-vel, illetve OTH-al
        //végződnek, a group-ra (GRP), illetve group-on
        //kívüli (other) user-ekre (OTH) vonatkoznak
        printf("%c",(inode.st_mode&S_IRUSR)? 'r' : '-');
        printf("%c",(inode.st_mode&S_IWUSR)? 'w' : '-');
        printf("%c",(inode.st_mode&S_IXUSR)? 'x' : '-');
        printf("%c",(inode.st_mode&S_IRGRP)? 'r' : '-');
        printf("%c",(inode.st_mode&S_IWGRP)? 'w' : '-');
        printf("%c",(inode.st_mode&S_IXGRP)? 'x' : '-');
        printf("%c",(inode.st_mode&S_IROTH)? 'r' : '-');
        printf("%c",(inode.st_mode&S_IWOTH)? 'w' : '-');
        printf("%c",(inode.st_mode&S_IXOTH)? 'x' : '-');
        printf("\n");


        //Felhasználó user-ének kiíratása

        pwd = getpwuid(inode.st_uid);
        
        //Ha a pwd talál user-t (jó return value-t kap), kiírja a usert.
        if (pwd)
        {
            printf("Owner's username: %s\n", (*pwd).pw_name);
        }

        printf("\n");

    //Folyamatok és a fork rendszerhívás

        //pid megszerzése, szülő pid megszerzése
        
        pid_t own_pid = getpid();
        pid_t parent_pid = getppid(); //get parent pid

        printf("A saját PID-ünk: %d\n", own_pid);
        printf("A szülő folyamat PID-je: %d\n", parent_pid);
        printf("\n");

        //fork létrehozása, futtatása
        int x_2 = 0;
        pid_t pid; //a pid_t egy egész típus

        printf("Start... x = %d\n", x_2);
        pid = fork();

        if (pid == 0)   //Child folyamat, stderr-re printel
        {
            x_2 = 1;
            fprintf(stderr, "Child... x = %d (PID is %d, Parent PID is %d)\n", x_2, getpid(), getppid());
            sleep(2); //mintha dolgozna
            fprintf(stderr, "Child ps:\n");
            system("ps -l | grep fork >&2"); //a grep-be átpipeoljuk a ps -l kimenetét
                                             //és csak azokat a sorokat kérjük, amikben
                                             //szerepel a "fork" szó.
                                             //a ">&2" kód irányítja át stderr-re
            sleep(2);
            fprintf(stderr, "End child. PID=%d\n",getpid());
            printf("\n");
        }
        else //Szülő folyamat (stdout-ra printel)
        {
            x_2 = 2;
            fprintf(stdout, "Parent... x = %d, PID is: %d\n", x_2, getpid());
            sleep(6);
            fprintf(stdout, "Parent ps:\n");
            system("ps -l | grep fork");
            sleep(2);
            fprintf(stdout, "End parent. PID=%d\n", getpid());
            printf("\n");
        }

    //Signal kezeléshez lásd a mellékelt signal.c file-t.
    //interferenciában volt a fork-olás példával,
    //ezért külön fileban van.
    
    return 0;
}