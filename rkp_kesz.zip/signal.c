#include <stdio.h>
#include <unistd.h>
#include <signal.h>

void ToDo(int sig)
{
    printf("\n  Ouch! It hurts.\n");
    signal(SIGINT, SIG_DFL); // Visszatéríti a programot
                             // az alap jelkezelésre
}


/*Ez a program annyit csinál, hogy a CTRL + C bill. kombinációt
átdefiniálja egy lenyomás erejéig arra, hogy azt írja ki, hogy
"Ouch! It hurts.". Ezután a SIG_DFL visszaállítja a CTRL + C eredeti
működését. A signal() függvény két paramétere az, hogy melyik signalt
(ebben az esetben a SIGINT-et, melyet CTRL + C-vel küldünk terminalban)
, és hogy mire szeretnénk átállítani. Az első lesz a signal, a második
pedig az, hogy mit csináljon a signal kiadása esetén.
*/
int main()
{
    int i;

    signal(SIGINT, ToDo);

    printf("Start...\n");
    for(i=1;i<=10;i++)
    {
        sleep(1);
        printf(" sleeptime: %ds\n",i);
    }

    return 0;
}